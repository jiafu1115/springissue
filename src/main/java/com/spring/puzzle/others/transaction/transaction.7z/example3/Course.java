package com.spring.puzzle.others.transaction.example3;

import lombok.Data;

@Data
public class Course {
    private String courseName;
    private Integer number;
}
