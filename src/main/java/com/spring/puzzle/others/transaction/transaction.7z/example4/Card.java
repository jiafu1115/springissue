package com.spring.puzzle.others.transaction.example4;

import lombok.Data;

@Data
public class Card {
    private Integer id;
    private Integer studentId;
    private Integer balance;
}
